'use client'

import { useMemo, useState } from 'react'
import useSWR from 'swr'
import {
  Activity,
  AlertTriangle,
  BadgeCheck,
  BarChart3,
  Bot,
  CheckCircle2,
  CircleDollarSign,
  FileSearch,
  Layers,
  Loader2,
  Play,
  ShieldAlert,
  Target,
  TrendingUp,
  Wallet,
  XCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { KpiCard } from '@/components/kpi-card'
import { SectionCard } from '@/components/section-card'
import { DataTable } from '@/components/data-table'
import {
  CategoryBarChart,
  OutcomeDonut,
  type CategoryDatum,
} from '@/components/charts'
import { ArchitectureSection } from '@/components/architecture-section'
import {
  formatINR,
  formatNumber,
  formatPercent,
  jsonFetcher,
  runEvaluation,
  type Metrics,
  type TableResponse,
} from '@/lib/recoverai'

// Literal color values — Recharts sets `fill` as an SVG attribute, which does
// not resolve CSS var() custom properties. These mirror the --chart-* tokens.
const CHART = {
  emerald: 'oklch(0.76 0.15 162)',
  amber: 'oklch(0.82 0.14 78)',
  red: 'oklch(0.64 0.2 22)',
  blue: 'oklch(0.66 0.14 244)',
  slate: 'oklch(0.55 0.02 255)',
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex items-center justify-center rounded-lg border border-dashed border-border py-10 text-sm text-muted-foreground">
      {message}
    </div>
  )
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-2 text-sm text-muted-foreground">
      <span
        className="size-2.5 rounded-full"
        style={{ backgroundColor: color }}
        aria-hidden="true"
      />
      {label}
    </span>
  )
}

export function Dashboard() {
  const [running, setRunning] = useState(false)

  const metrics = useSWR<Metrics>('/metrics', jsonFetcher, {
    refreshInterval: 0,
  })
  const recovery = useSWR<TableResponse>('/recovery-outcomes', jsonFetcher)
  const exceptions = useSWR<TableResponse>('/exceptions', jsonFetcher)
  const policy = useSWR<TableResponse>('/policy-decisions', jsonFetcher)

  const connected = !metrics.error && metrics.data !== undefined
  const loading = metrics.isLoading && !metrics.data

  const m = metrics.data ?? {}

  const revenueData: CategoryDatum[] = useMemo(
    () => [
      { name: 'Revenue at Risk', value: Number(m.revenue_at_risk) || 0, color: CHART.amber },
      { name: 'Revenue Recovered', value: Number(m.revenue_recovered) || 0, color: CHART.emerald },
      { name: 'Revenue Unrecovered', value: Number(m.revenue_unrecovered) || 0, color: CHART.red },
    ],
    [m.revenue_at_risk, m.revenue_recovered, m.revenue_unrecovered],
  )

  const outcomeData: CategoryDatum[] = useMemo(
    () => [
      { name: 'Successful', value: Number(m.successful_recoveries) || 0, color: CHART.emerald },
      { name: 'Failed', value: Number(m.failed_recoveries) || 0, color: CHART.red },
    ],
    [m.successful_recoveries, m.failed_recoveries],
  )

  const policyRows = policy.data?.data ?? []
  const policyActionData: CategoryDatum[] = useMemo(() => {
    const counts = new Map<string, number>()
    for (const row of policyRows) {
      const action = row.action != null ? String(row.action) : 'unknown'
      counts.set(action, (counts.get(action) ?? 0) + 1)
    }
    const palette = [CHART.emerald, CHART.blue, CHART.amber, CHART.slate, CHART.red]
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([name, value], i) => ({
        name: name.replace(/_/g, ' '),
        value,
        color: palette[i % palette.length],
      }))
  }, [policyRows])

  async function handleRun() {
    setRunning(true)
    const t = toast.loading(
      'Running Detection → Diagnosis → Policy → Execution → Recovery → Metrics...',
    )
    try {
      await runEvaluation()
      toast.success('Recovery evaluation completed', { id: t })
      await Promise.all([
        metrics.mutate(),
        recovery.mutate(),
        exceptions.mutate(),
        policy.mutate(),
      ])
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Evaluation failed', {
        id: t,
      })
    } finally {
      setRunning(false)
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 px-4 py-8 md:px-8">
      {/* Header */}
      <header className="flex flex-col gap-5 border-b border-border pb-6 md:flex-row md:items-start md:justify-between">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-xl bg-primary/15">
              <CircleDollarSign className="size-5.5 text-primary" aria-hidden="true" />
            </span>
            <div className="flex flex-col">
              <h1 className="text-2xl font-semibold tracking-tight text-foreground">
                RecoverAI
              </h1>
              <p className="text-sm text-muted-foreground">
                AI Revenue Recovery Controller
              </p>
            </div>
          </div>
          <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground text-pretty">
            Detect revenue at risk, diagnose the failure, choose the best
            recovery action, execute recovery, and measure the outcome.
          </p>
        </div>

        <div className="flex flex-col items-start gap-3 md:items-end">
          {connected ? (
            <Badge className="gap-1.5 border-[var(--chart-1)]/30 bg-[var(--chart-1)]/12 text-[var(--chart-1)]">
              <span className="size-1.5 rounded-full bg-[var(--chart-1)]" />
              Connected to FastAPI
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="gap-1.5 border-destructive/40 text-destructive"
            >
              <span className="size-1.5 rounded-full bg-destructive" />
              Backend offline
            </Badge>
          )}
          <Button
            onClick={handleRun}
            disabled={running || !connected}
            size="lg"
            className="gap-2"
          >
            {running ? (
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            ) : (
              <Play className="size-4" aria-hidden="true" />
            )}
            {running ? 'Running pipeline...' : 'Run Recovery Evaluation'}
          </Button>
        </div>
      </header>

      {/* Backend offline notice */}
      {!loading && !connected ? (
        <div className="flex flex-col gap-2 rounded-lg border border-destructive/30 bg-destructive/8 p-5">
          <div className="flex items-center gap-2 font-medium text-destructive">
            <ShieldAlert className="size-4" aria-hidden="true" />
            RecoverAI FastAPI is not available
          </div>
          <p className="text-sm text-muted-foreground">
            Start the backend and make sure it is reachable from this app:
          </p>
          <code className="w-fit rounded-md bg-muted px-3 py-1.5 font-mono text-sm text-foreground">
            uvicorn backend.api:app --reload
          </code>
          <p className="text-xs text-muted-foreground">
            The dashboard proxies requests to{' '}
            <span className="font-mono">RECOVERAI_API_URL</span> (defaults to{' '}
            <span className="font-mono">http://127.0.0.1:8000</span>).
          </p>
        </div>
      ) : null}

      {/* KPI grid */}
      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
      ) : connected ? (
        <>
          <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <KpiCard
              label="Records Evaluated"
              value={formatNumber(m.records_evaluated as number)}
              icon={Layers}
            />
            <KpiCard
              label="Revenue at Risk"
              value={formatINR(m.revenue_at_risk as number)}
              icon={Wallet}
              accent="warning"
            />
            <KpiCard
              label="Revenue Recovered"
              value={formatINR(m.revenue_recovered as number)}
              icon={TrendingUp}
              accent="positive"
            />
            <KpiCard
              label="Recovery Rate"
              value={formatPercent(m.recovery_rate_percent as number)}
              icon={Target}
              accent="positive"
            />
            <KpiCard
              label="Recovery Attempts"
              value={formatNumber(m.recovery_attempts as number)}
              icon={Activity}
            />
            <KpiCard
              label="Successful Recoveries"
              value={formatNumber(m.successful_recoveries as number)}
              icon={CheckCircle2}
              accent="positive"
            />
            <KpiCard
              label="Failed Recoveries"
              value={formatNumber(m.failed_recoveries as number)}
              icon={XCircle}
              accent="negative"
            />
            <KpiCard
              label="Exceptions"
              value={formatNumber(m.exception_count as number)}
              icon={AlertTriangle}
              accent="negative"
            />
          </section>

          {m.evaluation_type ? (
            <div className="flex items-center gap-2 rounded-lg border border-[var(--chart-2)]/25 bg-[var(--chart-2)]/8 px-4 py-3 text-sm text-muted-foreground">
              <BadgeCheck className="size-4 text-[var(--chart-2)]" aria-hidden="true" />
              Evaluation type:{' '}
              <span className="font-medium uppercase text-foreground">
                {String(m.evaluation_type)}
              </span>
              — recovery and revenue figures shown are synthetic evaluation
              results.
            </div>
          ) : null}

          {/* Charts row */}
          <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <SectionCard
              title="Revenue Overview"
              icon={CircleDollarSign}
              description="At risk vs. recovered vs. unrecovered."
            >
              <CategoryBarChart data={revenueData} valueFormatter={formatINR} />
            </SectionCard>

            <SectionCard
              title="Recovery Outcomes"
              icon={BarChart3}
              description="Successful vs. failed recovery attempts."
            >
              <OutcomeDonut data={outcomeData} valueFormatter={formatNumber} />
              <div className="mt-2 flex items-center justify-center gap-6">
                {outcomeData.map((d) => (
                  <LegendDot key={d.name} color={d.color} label={d.name} />
                ))}
              </div>
            </SectionCard>
          </section>

          {/* Policy */}
          <SectionCard
            title="AI Policy Decisions"
            icon={Bot}
            description="Distribution of recovery actions chosen by the policy layer."
          >
            {policyActionData.length ? (
              <>
                <CategoryBarChart
                  data={policyActionData}
                  valueFormatter={formatNumber}
                />
                <div className="mt-6">
                  <DataTable rows={policyRows} highlightColumn="action" />
                </div>
              </>
            ) : (
              <EmptyState message="No policy decisions available yet. Run an evaluation to generate them." />
            )}
          </SectionCard>

          {/* Recovery audit */}
          <SectionCard
            title="Recovery Audit"
            icon={FileSearch}
            description="Full log of recovery outcomes per payment."
          >
            {recovery.data?.data?.length ? (
              <DataTable rows={recovery.data.data} highlightColumn="outcome" />
            ) : (
              <EmptyState message="No recovery outcome records available." />
            )}
          </SectionCard>

          {/* Exceptions */}
          <SectionCard
            title="Recovery Exceptions"
            icon={AlertTriangle}
            description="Failed recovery records that need attention."
            action={
              exceptions.data?.count ? (
                <Badge
                  variant="outline"
                  className="border-destructive/40 text-destructive"
                >
                  {exceptions.data.count} failed
                </Badge>
              ) : null
            }
          >
            {exceptions.data?.data?.length ? (
              <DataTable rows={exceptions.data.data} highlightColumn="outcome" />
            ) : (
              <div className="flex items-center gap-2 rounded-lg border border-[var(--chart-1)]/25 bg-[var(--chart-1)]/8 px-4 py-3 text-sm text-[var(--chart-1)]">
                <CheckCircle2 className="size-4" aria-hidden="true" />
                No recovery exceptions detected.
              </div>
            )}
          </SectionCard>

          <ArchitectureSection />
        </>
      ) : null}

      <footer className="border-t border-border pt-6 text-xs text-muted-foreground">
        RecoverAI · AI Revenue Recovery Controller · FastAPI + Next.js
      </footer>
    </div>
  )
}
